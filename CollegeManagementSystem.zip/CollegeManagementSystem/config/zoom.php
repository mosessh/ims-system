<?php

return [
    'api_key' => env('ZOOM_KEY'),
    'api_secret' => env('ZOOM_SECRET'),
];
